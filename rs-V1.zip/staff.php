<title>Educators Point</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<script src="js/responsiveslides.min.js"></script>
<script>
    // You can also use "$(window).load(function() {"
    $(function () {
      // Slideshow 1
      $("#slider1").responsiveSlides({
         auto: true,
		 nav: true,
		 speed: 500,
		 namespace: "callbacks",
      });
    });
  </script>
  <!-- web-fonts -->
  <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600italic,400italic,600,300italic,300,700italic,800,800italic' rel='stylesheet' type='text/css'>
	<!-- web-fonts -->
  <script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script>
<div class="our-staff">
			<div class="container">
				<div class="our-staff-head text-center">
					<header>
						<h3>Our Staff</h3>
						<p>Lorem Ipsum is simply dummy Business industry doloremque laudantium.</p>
					</header>
				<div class="our-staff-grids text-center">
					<div class="col-md-3 our-staff-grid">
						<div class="view view-seventh">
								<a href="#"><img class="img-responsive" src="images/s1.jpg" alt=""></a>
					                 <div class="mask">
				 						<ul class="staff-social-icons">
											<li><a href="#"><span class="facebook"> </span></a></li>
											<li><a href="#"><span class="twitter"> </span></a></li>
										</ul>
                   					 </div>
                   					 <h4>Doris Wilson</h4>
			                    <p>Sed ut perspiciatis unde omnis iste natus laudantium.</p>
                   		</div>
					</div>
					<div class="col-md-3 our-staff-grid">
						<div class="view view-seventh">
								<a href="#"><img class="img-responsive" src="images/s2.jpg" alt=""></a>
					                 <div class="mask">
				 						<ul class="staff-social-icons">
											<li><a href="#"><span class="facebook"> </span></a></li>
											<li><a href="#"><span class="twitter"> </span></a></li>
										</ul>
                   					 </div>
                   					 <h4>Amy Smith</h4>
			                    <p>Sed ut perspiciatis unde omnis iste natus error laudantium.</p>
                   		</div>
					</div>
					<div class="col-md-3 our-staff-grid">
						<div class="view view-seventh">
								<a href="#"><img class="img-responsive" src="images/s3.jpg" alt=""></a>
					                 <div class="mask">
				 						<ul class="staff-social-icons">
											<li><a href="#"><span class="facebook"> </span></a></li>
											<li><a href="#"><span class="twitter"> </span></a></li>
										</ul>
                   					 </div>
                   					 <h4>Edna Francis</h4>
			                    <p>Sed ut perspiciatis unde omnis accusantium laudantium.</p>
                   		</div>
					</div>
					<div class="col-md-3 our-staff-grid">
						<div class="view view-seventh">
								<a href="#"><img class="img-responsive" src="images/s4.jpg" alt=""></a>
					                 <div class="mask">
				 						<ul class="staff-social-icons">
											<li><a href="#"><span class="facebook"> </span></a></li>
											<li><a href="#"><span class="twitter"> </span></a></li>
										</ul>
                   					 </div>
                   					 <h4>Jennie Crigler</h4>
			                    <p>Sed ut sit voluptatem accusantium doloremque laudantium.</p>
                   		</div>
					</div>
					<div class="clearfix"></div>
				</div>
				</div>
			</div>
		</div>