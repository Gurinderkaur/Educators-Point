<?php
include_once("header.php");
?>

<div class="container" id="content">
<h1 class="heading text-center">Download/Upload Tutorials</h1>
	<form name="form1" method="post" action="">
	  <table width="900" border="0" align="center">
        <tr>
          <td  colspan="2">&nbsp;</td>
          <td  colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td  colspan="2">&nbsp;</td>
          <td  colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td  colspan="2">&nbsp;</td>
          <td  colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td  colspan="2">&nbsp;</td>
          <td  colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td  colspan="2">&nbsp;</td>
          <td  colspan="2">&nbsp;</td>
        </tr>
         <tr>
          <td  colspan="2">&nbsp;</td>
          <td  colspan="2">&nbsp;</td>
          <td  colspan="2">&nbsp;</td>
          </tr>
	    
	    <tr>
	      <td align="center"><a href="useraddtutorial.php"><img src="images/upload.png"></a></td>
	      <td align="center"><a href="choose.php"><img src="images/dondoc.png"></a></td>
        </tr>
      </table>
</form>
</div>
<?php
include_once("footer.php");
?>