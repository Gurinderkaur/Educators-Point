<title>Educators Point</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<script src="js/responsiveslides.min.js"></script>
<script>
    // You can also use "$(window).load(function() {"
    $(function () {
      // Slideshow 1
      $("#slider1").responsiveSlides({
         auto: true,
		 nav: true,
		 speed: 500,
		 namespace: "callbacks",
      });
    });
  </script>
  <!-- web-fonts -->
  <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600italic,400italic,600,300italic,300,700italic,800,800italic' rel='stylesheet' type='text/css'>
	<!-- web-fonts -->
  <script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script><div class="service-section">
				<div class="container">
					<div class="service-section-head text-center">
						<header>
							<h3>Our Services</h3>
							<p>Lorem Ipsum is simply error sit voluptatem accusantium doloremque laudantium.</p>
						</header>
					</div>
					<div class="service-section-grids">
						<div class="col-md-4 service-grid">
							<div class="service-section-grid">
								<div class="icon">
									<span class="d1 glyphicon glyphicon-pencil"></span>
								</div>
								<div class="icon-text">
									<a href="single.html">Lorem Ipsum is simply</a>
									<p>Lorem Ipsum is simply. Lorem Ipsum has been an unknown printer.</p>
								</div>
							</div>
							<div class="service-section-grid">
								<div class="icon">
									<span class="d2 glyphicon glyphicon-ok-sign"></span>
								</div>
								<div class="icon-text">
									<a href="single.html">Sed ut perspiciatis unde</a>
									<p>Many desktop publishing packages and web  web sites still in their infancy</p>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="col-md-4 service-grid">
							<div class="service-section-grid">
								<div class="icon">
									<span class="d4 glyphicon glyphicon-folder-open"></span>									
								</div>
								<div class="icon-text">
									<a href="single.html">Contrary to popular belief</a>
									<p>Many desktop publishing packages 'lorem ipsum' web sites still in their infancy</p>
								</div>
							</div>
							<div class="service-section-grid">
								<div class="icon">
									<span class="d5 glyphicon glyphicon-globe"></span>
								</div>
								<div class="icon-text">
									<a href="single.html">At vero eos et accusamus</a>
									<p>There are many variations of passages look even slightly believable.</p>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="col-md-4 service-grid">
							<div class="service-section-grid">
								<div class="icon">
									<span class="d6 glyphicon glyphicon-sort-by-alphabet"></span>									
								</div>
								<div class="icon-text">
									<a href="single.html">soluta nobis est eligendi</a>
									<p>Many desktop publishing packages 'lorem ipsum' will uncover their infancy</p>
								</div>
							</div>
							<div class="service-section-grid">
								<div class="icon">
									<span class="d7 glyphicon glyphicon-sort-by-order"></span>
								</div>
								<div class="icon-text">
									<a href="single.html">On the other hand</a>
									<p>There are many variations of humouror randomised slightly believable.</p>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>