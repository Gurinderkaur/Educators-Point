<?php
ob_start();
session_start();
include_once("header.php");

?>


<div class="container" id="content">
<?php

require_once("vals.php");
if(isset($_POST["signup"]))
{
	$name=$_POST["name"];
	$username=$_POST["username"];
	$password=$_POST["password"];
	$cpassword=$_POST["password2"];
$dob=$_POST["date"].$_POST["month"].$_POST["year"];
	$gender=$_POST["radio"];
	$country=$_POST["country"];
	$phone=$_POST["phone"];

$conn=mysqli_connect(host,username,password,dbname) or die("Error in connection".mysqli_connect_error());
$q="insert into signup(name,username,password,dob,gender,country,phone,usertype) values('$name','$username','$password' , '$dob'  , '$gender' , '$country','$phone','normal')";
$res=mysqli_query($conn,$q) or die("Error in query".mysqli_error($conn));
$cnt=mysqli_affected_rows($conn);
mysqli_close($conn);
if($cnt==1)
{
    header("location:index.php");
}
	
else
{
	$msg="signup unsuccessful,please try again later";
	print $msg;
	}	
	
	}
?>


<form name="form1" method="post" action="">
<table width="970" border="0" align="center" cellpadding="3" cellspacing="5">
        <tr >
          <td width="151" align="center">&nbsp;</td>
          <td width="833"><font size="+2"><u>SIGN UP<u></font></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td align="center">NAME</td>
         <td><label for="name"></label>
          <input type="text" name="name" id="name"></td>
        </tr>
         <tr>
          <td>&nbsp;</td>
          </tr>
        <tr>
        <td align="center">Username</td>
          <td><label for="username"></label>
      <input type="text" name="username" id="username" /></td>
        </tr>
        
         <tr>
          <td>&nbsp;</td>
          </tr>
       <tr>
         <td align="center">Password</td>
      <td><input type="password" name="password" id="password" /></td>
        </tr>
        
         <tr>
          <td>&nbsp;</td>
          </tr>
        <tr>
        <td align="center">Confirm Password</td>
      <td><input type="password" name="password2" id="password2" /></td>
        </tr>
        
         <tr>
          <td>&nbsp;</td>
          </tr>
        <tr>
          <td align="center">Birthday</td>
      <td><label for="date"></label>
        <select name="date" id="date">
          <?php
		  for($x=1;$x<=31;$x++)
		  
			  print"<option value='$x'>$x</option>"
		  
		  
		  ?>
        </select>
		  
		  
        <label for="month"></label>
        <select name="month" id="month">
          <option>January</option>
          <option>February</option>
          <option>March</option>
          <option>April</option>
          <option>May</option>
          <option>June</option>
          <option>July</option>
          <option>August</option>
          <option>September</option>
          <option>October</option>
          <option>November</option>
          <option>December</option>
        </select>
        <label for="year"></label>
        <select name="year" id="year">
          
          <?php
		  for($x=1950;$x<=2016;$x++)
		  
			  print"<option value='$x'>$x</option>"
		  
		  
		  ?>
      </select></td>
        </tr>
        
         <tr>
          <td>&nbsp;</td>
          </tr>
        <tr>
          <td align="center">Gender</td>
      <td><input type="radio" name="radio" id="Male" value="Male" />
      <label for="Male">Male</label>&nbsp;
      
      <label>
        <input type="radio" name="radio" id="Female" value="Female" />Female
      </label></td></font>
        </tr>
        
         <tr>
          <td>&nbsp;</td>
          </tr>
        <tr>
          <td align="center">Country</td>
      <td><label for="country"></label>
        <select name="country" id="country">
          <option>Afghanistan</option>
          <option>Albania</option>
          <option>Algeria</option>
          <option>Aruba</option>
          <option>Australia</option>
          <option>Austria</option>
          <option>Belarus</option>
          <option>belgium</option>
          <option>Bhutan</option>
          <option>Bolivia</option>
          <option>Brazil</option>
          <option>Burundi</option>
          <option>Colombia</option>
          <option>Cameroon</option>
          <option>Canada</option>
          <option>Cuba</option>
          <option>Cyprus</option>
          <option>Denmark</option>
          <option>Dominica</option>
          <option>Egypt</option>
          <option>Estonia</option>
          <option>Ethiopia</option>
          <option>Fiji</option>
          <option>Finland</option>
          <option>France</option>
          <option>Georgia</option>
          <option>Ghana</option>
          <option>Germany</option>
          <option>Hondurus</option>
          <option>Hong Kong</option>
          <option>Hungary</option>
          <option>Iceland</option>
          <option selected="selected">India</option>
          <option>Indonesia</option>
          <option>Iran</option>
          <option>Iraq</option>
          <option>Ireland</option>
          <option>Israel</option>
          <option>Italy</option>
          <option>Jamaica</option>
          <option>Japan</option>
          <option>Jordan</option>
          <option>Kenya</option>
          <option>Kiribati</option>
          <option>Kuwait</option>
          <option>Laos</option>
          <option>Latvia</option>
          <option>Lesotho</option>
          <option>Liberia</option>
          <option>Libya</option>
          <option>Macau</option>
          <option>Malawi</option>
          <option>Malaysia</option>
          <option>Maldives</option>
          <option>Malli</option>
          <option>Marshal island</option>
          <option>Mauritius</option>
          <option>Mexico</option>
          <option>Monacoo</option>
          <option>Moraco</option>
          <option>Nepal</option>
          <option>Netherland</option>
          <option>New Zealand</option>
          <option>Nigeria</option>
          <option>North Korea</option>
          <option>Norway</option>
          <option>Oman</option>
          <option>Pakistan</option>
          <option>Palau</option>
          <option>Palestine</option>
          <option>Peru</option>
          <option>Philippines</option>
          <option>Poland</option>
          <option>Portugal</option>
          <option>Qatar</option>
          <option>Romania</option>
          <option>Russia</option>
          <option>Rwanda</option>
          <option>Samao</option>
          <option>San Marino</option>
          <option>Saudi Arebia</option>
          <option>Serbia</option>
          <option>Sudan</option>
          <option>Suriname</option>
          <option>Swedan</option>
          <option>Singapore</option>
          <option>Solovia</option>
          <option>St. Lucia</option>
          <option>St. Peri</option>
          <option>Syria</option>
          <option>Tajikistan</option>
          <option>Thailang</option>
          <option>Timor</option>
          <option>Tonga</option>
          <option>Turkey</option>
          <option>Tunisia</option>
          <option>US Virgin land</option>
          <option>Uganda</option>
          <option>United Kingdom</option>
          <option>United States</option>
          <option>Uruguay</option>
          <option>Ukraine</option>
          <option>Vatican city</option>
          <option>Vietnam</option>
          <option>Wallis nad futana</option>
          <option>Yemen</option>
          <option>Zambia</option>
          <option>Zimbabwe</option>
        </select></td>
        </tr>
         <tr>
          <td>&nbsp;</td>
       </tr>
        <tr>
          <td align="center">Phone</td>
          <td><label for="phone"></label>
          <input type="text" name="phone" id="phone"></td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
          </tr>
          <tr >
          <td></td>
           <td ><input type="submit" name="signup" id="signup" value="signup" /></td>
        </tr>
      </table>

</form>
&nbsp;
&nbsp;
</div>
<?php
include_once("footer.php");

?>