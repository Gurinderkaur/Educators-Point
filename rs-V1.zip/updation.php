<?php
include_once("adminheader.php");
?>
<div class="container" id="content">
<form name="form1" method="post" action="">
  <table width="900" border="0" align="center">
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><h2><B><font size="+2"> Updation Panel</font></B></h2></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="178"><a href="adminaddsemester.php"><img src="images/sem.png" height="40px"></a></td>
      <td width="62">&nbsp;</td>
      <td width="205"><a href="adminaddsubject.php"><img src="images/sub.png" height="40px"></a></td>
      <td width="14">&nbsp;</td>
      <td width="207"><a href="adminaddtutorial.php"><img src="images/atut.png" height="40px"></a></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><a href="adminupsemester.php"><img src="images/usem.png" height="40px"></a></td>
      <td>&nbsp;</td>
      <td><a href="showsubject.php"><img src="images/usub.png" height="40px"></a></td>
      <td>&nbsp;</td>
      <td><a href="showtutorial.php"><img src="images/utut.png" height="40px"></a></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      </tr>
       <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</div>
<?php
include_once("footer.php");
?>
